#ifndef __DATRANSFORM_H__
#define __DATRANSFORM_H__

unsigned int uiADTransform();

#endif