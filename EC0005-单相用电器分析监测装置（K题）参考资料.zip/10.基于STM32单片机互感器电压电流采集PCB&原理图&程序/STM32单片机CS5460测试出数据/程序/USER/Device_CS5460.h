#ifndef __Device_CS5460_H
#define	__Device_CS5460_H

#include "stm32f10x.h"

#define   CS5460_SDI_SET                (GPIOB->ODR |= (u32)(GPIO_Pin_14))
#define   CS5460_SDI_CLR                (GPIOB->ODR &= (u32)(~GPIO_Pin_14))


#define   CS5460_RST_SET                (GPIOB->ODR |= (u32)(GPIO_Pin_12))
#define   CS5460_RST_CLR                (GPIOB->ODR &= (u32)(~GPIO_Pin_12))


#define   CS5460_SCK_SET                (GPIOA->ODR |= (u32)(GPIO_Pin_12))
#define   CS5460_SCK_CLR                (GPIOA->ODR &= (u32)(~GPIO_Pin_12))


#define   CS5460_SDO_SET                (GPIOA->ODR |= (u32)(GPIO_Pin_11))
#define   CS5460_SDO_CLR                (GPIOA->ODR &= (u32)(~GPIO_Pin_11))


#define   CS5460_CS_SET                 (GPIOA->ODR |= (u32)(GPIO_Pin_8))
#define   CS5460_CS_CLR                 (GPIOA->ODR &= (u32)(~GPIO_Pin_8))


#define	CS5460_SDO_READ		(Bit_SET == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11))


//#define   CS5460_SDI_SET                (GPIOC->ODR |= (u32)(GPIO_Pin_7))
//#define   CS5460_SDI_CLR                (GPIOC->ODR &= (u32)(~GPIO_Pin_7))


//#define   CS5460_RST_SET                (GPIOC->ODR |= (u32)(GPIO_Pin_10))
//#define   CS5460_RST_CLR                (GPIOC->ODR &= (u32)(~GPIO_Pin_10))


//#define   CS5460_SCK_SET                (GPIOC->ODR |= (u32)(GPIO_Pin_8))
//#define   CS5460_SCK_CLR                (GPIOC->ODR &= (u32)(~GPIO_Pin_8))


//#define   CS5460_SDO_SET                (GPIOC->ODR |= (u32)(GPIO_Pin_6))
//#define   CS5460_SDO_CLR                (GPIOC->ODR &= (u32)(~GPIO_Pin_6))


//#define   CS5460_CS_SET                 (GPIOC->ODR |= (u32)(GPIO_Pin_9))
//#define   CS5460_CS_CLR                 (GPIOC->ODR &= (u32)(~GPIO_Pin_9))

//#define	CS5460_SDO_READ		(Bit_SET == GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_6))  //������

//===========    Calibration Register Address(read)   ============
#define  DC_U_OFF_R   0x06
#define  DC_I_OFF_R   0x02
#define  AC_U_GAIN_R  0x08
#define  AC_I_GAIN_R  0x04
#define  AC_U_OFF_R   0x22
#define  AC_I_OFF_R   0x20
//===========    Calibration Register Address(write)   ============
#define  DC_U_OFF_WR   0x46
#define  DC_I_OFF_WR   0x42
#define  AC_U_GAIN_WR  0x48
#define  AC_I_GAIN_WR  0x44
#define  AC_U_OFF_WR   0x62
#define  AC_I_OFF_WR   0x60
//===========    Measure result Register Address(read)  ============
#define  RMS_U         0x18
#define  RMS_I         0x16
#define  RMS_E         0x14

void Reset5460(void);
void WriteRegister5460(u8 com, u32 Data);
u32 ReadRegister5460(u8 com);
void WriteComTo5460(u8 com);
void WriteTo5460(u8 Data);
void ConfigCS5460IO(void);
void delay_ms(u16 ms);
void delay_10us(void);
void delay_2us(void);
void Sync5460(void);
void ClearDRDY(void);
// void delay();

#endif 
