

void _delay_us(unsigned char);
void _delay_ms(unsigned int);
void delay(unsigned int c);
