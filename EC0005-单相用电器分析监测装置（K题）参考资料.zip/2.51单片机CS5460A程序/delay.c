
#include"delay.h"
#include"intrins.h"

/***************************************************************
*��ʱ����
***************************************************************/
void _delay_us(unsigned char count)
{
	while(count--)
	{
		unsigned char ii;
		for(ii=2;ii>0;ii--);	
	}
}
void _delay_ms(unsigned int ms)
{
	unsigned int iii;
	unsigned char j;
	for(iii=0;iii<ms;iii++)
	{
		for(j=0;j<250;j++)
		{
			_nop_();		
		}
	}

}
void delay(unsigned int c)
{
	unsigned int  x,y;
	for(x=c;x>0;x--)
		for(y=256;y>0;y--);
}													     