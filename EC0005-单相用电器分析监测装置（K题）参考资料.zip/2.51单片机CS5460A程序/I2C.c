
#include"I2C.h"

sbit SCL = P6^3;
sbit SDA = P6^4;

void start()  //��ʼ�ź�
{   
	SFRPAGE   = CONFIG_PAGE;
	P6MDOUT   = 0xFF;
    SDA=1;
    delay_us(1);
    SCL=1;
    delay_us(1);
    SDA=0;
    delay_us(1);
}
void stop()   //ֹͣ
{
    SFRPAGE   = CONFIG_PAGE;
	P6MDOUT   = 0xFF;
	SDA=0;
    delay_us(1);
    SCL=1;
    delay_us(1);
    SDA=1;
	delay_ms(5);
}
void respons()  //�ȴ�Ӧ��
{
    uchar xdata i;
	SFRPAGE   = CONFIG_PAGE;
	P6MDOUT   = 0x00;
    SCL=1;
    delay_us(1);
    while((SDA==1)&&(i<250))i++;
    SCL=0;
    delay_us(1);
}
void init_24c16()//IIC��ʼ������
{
    SFRPAGE   = CONFIG_PAGE;
	P6MDOUT   = 0xFF;
    SDA=1;
    delay_us(1);
    SCL=1;
    delay_us(1);
}
void write_byte(uchar date)//дһ���ֽں���
{
    uchar xdata i,temp;
	SFRPAGE   = CONFIG_PAGE;
	P6MDOUT   = 0xFF;
    temp=date;
    for(i=0;i<8;i++)
    {
        temp=temp<<1;
        SCL=0;
        delay_us(1);
        SDA=CY;
        delay_us(1);
        SCL=1;
        delay_us(1);
    }
    SCL=0;
    delay_us(1);
    SDA=1;
    delay_us(1);
}
uchar read_byte()//��һ���ֽں���
{
    uchar xdata i,k;
	SFRPAGE   = CONFIG_PAGE;
	P6MDOUT   = 0xFF;
    SCL=0;
    delay_us(1);
    SDA=1;
    delay_us(1);
	SFRPAGE   = CONFIG_PAGE;
	P6MDOUT   = 0x00;
    for(i=0;i<8;i++)
    {
        SCL=1;
        delay_us(1);	
        k=(k<<1)|SDA;
        SCL=0;
        delay_us(1);	
    }
    return k;
}
void write_add(uint add,uchar date)//ָ����ַдһ���ֽ�
{	 
	uchar xdata addh,addl;
	addh=add>>8;
	addh<<=1;
	addl=add&0x00ff;
	start();
	write_byte(addh+0xa0);	 //������ַ
	//write_byte(0xa0);
	respons();
	write_byte(addl);		 //λ��
	respons();
	write_byte(date);
	respons();
	stop();
	delay_ms(1);
}
uchar read_add(uint add)//ָ����ַ��һ���ֽ�
{
    uchar xdata date,addh,addl;
	addh=add>>8;
	addh<<=1;			 //������ַ
	addl=add&0x00ff;
	start();
	write_byte(addh|0xa0);	
	//write_byte(0xa0);
	respons();
	//write_byte(add);
	write_byte(addl);	  //�����ڲ�������ַ�ڼ�����Ԫ�洢����
	respons();
	start();
	write_byte(addh|0xa1);
	//write_byte(0xa1);
	respons();
	date=read_byte();
	stop();
    return date;
} 
void readE2prom(uint add,uchar *read)
{
	uchar xdata i;
//	EA=0;
	for(i=0;i<8;i++)
	{
		read[i]=read_add(add);
		add++;
//		delayms(10);
	}
//	EA=1;
}
void writeE2prom(uint add,uchar *write)
{
	uchar xdata i;
//	EA=0;
	for(i=0;i<8;i++)
	{	
		write_add(add,write[i]);
		add++;
	}
//	EA=1;
}